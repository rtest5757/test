from __future__ import annotations

import datetime
import os
import typing
import reversion
from collections import defaultdict
from pathlib import Path
from typing import Optional, Iterable, Dict, Sequence, List
from django.contrib.admin.models import LogEntry, CHANGE
from django.contrib.contenttypes.models import ContentType
from django.contrib.postgres.fields import ArrayField
from audit_builder.utils import sanitize_filename
from django.conf import settings
from django.contrib.auth.models import Permission, User
from django.contrib.contenttypes.fields import GenericRelation
from django.contrib.postgres.search import SearchVector
from django.core.exceptions import ValidationError
from django.core.validators import MinValueValidator, FileExtensionValidator
from django.db import models, transaction
from django.db.models import PROTECT, CASCADE, SET_NULL, Q, DurationField, F
from django.templatetags.static import static
from django.urls import reverse
from django.utils import timezone
from django.utils.functional import cached_property
from django.utils.html import format_html
from django.utils.translation import gettext_lazy as _
from files.utils import create_model_field_url
from megdocs.constants import REVIEW_FREQUENCY_ANNUAL, REVIEW_FREQUENCY_CHOICES, MANAGER_CODENAMES, REVIEWER_CODENAMES, \
    VIEWER_CODENAMES, FOLDER_PERMISSION_RULE_ROLE_CHOICES, ALLOWED_DOCUMENT_EXTENSIONS, EXTENSION_PDF, EXTENSIONS_IMAGE, \
    EXTENSIONS_MS_WORD, EXTENSIONS_MS_EXCEL, ALLOWED_SOURCE_DOCUMENT_EXTENSIONS, DOCUMENT_SEARCH_TEXT_TITLE, \
    DOCUMENT_SEARCH_TEXT_CONTENT, DOCUMENT_SEARCH_TEXT_TAGS, REVIEW_INTERVAL_REMIND_BEFORE, \
    DOCUMENT_CHANGE_REQUEST_STATUS_CHOICES, DOCUMENT_CHANGE_REQUEST_STATUS_PENDING, \
    DOCUMENT_CHANGE_REQUEST_STATUS_APPROVED, DOCUMENT_CHANGE_REQUEST_STATUS_DECLINED, \
    CHANGE_REQUEST_ACTION_TYPES, CHANGE_REQUEST_ACTION_TYPE_NEW, CHANGE_REQUEST_ACTION_TYPE_EDIT, \
    CHANGE_REQUEST_ACTION_TYPE_ARCHIVE, DOCUMENT_CHANGE_REQUEST_STATUS_FINISHED
from megforms.models import BaseModel, BaseQuerySet, Auditor, Institution, AuditorQueryset
from megforms.utils import log_debug, get_dotted_path
from mptt.models import MPTTModel, TreeForeignKey
from mptt.querysets import TreeQuerySet
from pdfminer.high_level import extract_text
from taggit.managers import TaggableManager
from megforms.constants import LEVEL_GROUP, LEVEL_INSTITUTION, FORM_LEVEL_CHOICES, VERSION_APPROVAL_STATUS_CHOICES, \
    VERSION_APPROVAL_STATUS_APPROVED, VERSION_APPROVAL_STATUS_DECLINED, MEGDOCS_CHANGE_REQUESTS_ENABLED
from utils.query import SubqueryCount

if typing.TYPE_CHECKING:
    from megforms.models import Ward

FIRST_REVISION = 1


class DocumentSearchQuerysetMixin:
    document_relation_prefix = ''

    def search(self, value: str, search_in: list[str] = None):
        """
        Search document by string

        :param value: string to search by
        :param search_in: fields to search in, options: "title", "content", "tags", by default it will search on all
        :return: filtered queryset
        """
        filter_q = Q()
        search_vector_fields: set[str] = set()

        if not search_in or DOCUMENT_SEARCH_TEXT_TITLE in search_in:
            search_vector_fields.add(f'{self.document_relation_prefix}name')
            search_vector_fields.add(f'{self.document_relation_prefix}description')
            filter_q |= Q(**{f'{self.document_relation_prefix}name__icontains': value})

        if not search_in or DOCUMENT_SEARCH_TEXT_CONTENT in search_in:
            version_ids = Version.objects.order_by().annotate(
                search=SearchVector('content')
            ).filter(
                pk__in=self.values_list(f'{self.document_relation_prefix}current_version_id', flat=True),
                search=value,
            ).values_list('pk', flat=True)

            filter_q |= Q(**{f'{self.document_relation_prefix}current_version__in': version_ids})

        if not search_in or DOCUMENT_SEARCH_TEXT_TAGS in search_in:
            search_vector_fields.add(f'{self.document_relation_prefix}tags__name')
            filter_q |= Q(**{f'{self.document_relation_prefix}tags__name__icontains': value})

        if search_vector_fields:
            pk_qs = self.annotate(
                search=SearchVector(*search_vector_fields),
            ).filter(filter_q | Q(search=value))
        else:
            pk_qs = self.filter(filter_q)

        return self.filter(pk__in=pk_qs.order_by().values_list('pk', flat=True))


class DocumentQuerySet(DocumentSearchQuerysetMixin, BaseQuerySet):

    def due_review(self, exact=True, for_date: Optional[datetime.date] = None):
        """
        Documents that are due for review today
        :arg exact whether to only return versions due today. Pass False to also show versions due for review in the past
        :arg for_date today's date
        """
        date_lookup = 'current_version__creation_date' if exact else 'current_version__creation_date__lte'
        for_date: datetime.date = for_date or timezone.localdate()
        return self.filter(review_interval__isnull=False, **{date_lookup: for_date - F('review_interval')})

    def review_range(self, from_date: datetime.date, to_date: datetime.date) -> DocumentQuerySet:
        """Documents that are due for review in given date range"""
        assert isinstance(from_date, datetime.date)
        assert isinstance(to_date, datetime.date)
        return self.filter(review_interval__isnull=False, current_version__creation_date__range=(
            from_date - F('review_interval'),
            to_date - F('review_interval'),
        ))

    def upcoming_due_review(self, for_date: Optional[datetime.date] = None) -> DocumentQuerySet:
        """
        Documents with upcoming review dates

        :param for_date: today's date
        """
        for_date: datetime.date = for_date or timezone.localdate()
        return self.due_review(exact=True, for_date=for_date + REVIEW_INTERVAL_REMIND_BEFORE)

    def review_map(self) -> dict[datetime.date, Sequence[Document]]:
        """ Creates a dict mapping dates to documents due for review on that date """
        result: Dict[datetime.date, List['Document']] = defaultdict(list)
        document: Document
        for document in self.select_related('current_version').iterator():
            result[document.review_date].append(document)
        return result

    def live_documents(self):
        return self.exclude(pk__in=self.archived_documents().values_list('pk', flat=True))

    def approved(self):
        return self.filter(current_version__approved=True)

    def archived_documents(self):
        q: Q = Q()
        for institution_id in self.values_list('institution', flat=True):
            q |= Q(institution_id=institution_id, archived=True)
        return self.filter(q)

    def for_institutions(self, institutions: Iterable['Institution']):
        return self.filter(institution__in=institutions)

    def for_wards(self, wards: Iterable['Ward']):
        return self.filter(Q(wards__in=wards) | Q(folder__in=Folder.objects.published().for_wards(wards)))

    def for_user(self, user: User, permissions: list[str] = None):
        from accounts.utils import get_user_institutions
        qs = self.for_institutions(get_user_institutions(user))
        return qs.filter(Q(folder__in=user.auditor.allowed_folders(permissions)) | Q(folder=None))

    def for_categories(self, categories: Iterable['DocumentCategory']):
        return self.filter(category__in=categories)


class DocumentRelationQuerySet(BaseQuerySet):
    """Queryset for models which have a foreign key relation to Document"""

    def for_institutions(self, institutions: Iterable['Institution']):
        return self.filter(document__institution__in=institutions)

    def for_user(self, user: User):
        return self.filter(document__in=Document.objects.for_user(user))

    def documents(self) -> DocumentQuerySet:
        return Document.objects.filter(pk__in=self.values_list('document_id'))


class Document(BaseModel):
    name = models.CharField(verbose_name=_('name'), max_length=70)
    description = models.TextField(verbose_name=_('description'), blank=True)
    owner = models.ForeignKey(verbose_name=_('owner'), to='megforms.Auditor', related_name='owned_documents', on_delete=PROTECT)
    leads = models.ManyToManyField(verbose_name=_('leads'), to='megforms.Auditor', related_name='lead_documents', blank=True, help_text=_("Users who have oversight over this document, but aren't the direct owner."))
    institution = models.ForeignKey(verbose_name=_('institution'), to='megforms.Institution', related_name='documents', on_delete=CASCADE)
    current_version = models.OneToOneField(verbose_name=_('current version'), to='megdocs.Version', related_name='document_published', help_text=_('Currently published version of this document'), on_delete=SET_NULL, null=True, blank=True, limit_choices_to={'approved': True})
    tags = TaggableManager(blank=True)
    review_interval = DurationField(verbose_name=_('review interval'), help_text=_('How often this document needs to be reviewed'), blank=True, null=True, default=REVIEW_FREQUENCY_ANNUAL, choices=REVIEW_FREQUENCY_CHOICES)
    required_approvals = models.PositiveSmallIntegerField(verbose_name=_('required approvals'), help_text=_("Define how many users must approve new document versions before publishing, approvals can come from the approver or reviewers. Default 1 means only the approver needs to approve the document"), default=1, validators=[MinValueValidator(1)])
    archived = models.BooleanField(verbose_name=_('archived'), default=False, help_text=_('Archived documents are no longer accessible by users'))
    folder = models.ForeignKey(verbose_name=_('folder'), to='megdocs.Folder', related_name='documents', on_delete=PROTECT, blank=True, null=True)
    forms = models.ManyToManyField(verbose_name=_('forms'), to='megforms.AuditForm', related_name='documents', blank=True)
    documents = models.ManyToManyField(verbose_name=_('documents'), to='megdocs.Document', blank=True)
    category = models.ForeignKey(verbose_name=_('category'), to='megdocs.DocumentCategory', related_name='documents', on_delete=PROTECT, blank=True, null=True)

    objects = DocumentQuerySet.as_manager()

    def __str__(self):
        return self.name

    def get_new_revision_number(self) -> int:
        """ Generates a new unused revision number for this document """
        self.versions: VersionQuerySet
        return self.versions.get_new_revision_number()

    @property
    def is_due_review(self) -> bool:
        """ Whether this document is due for a review now"""
        today: datetime.date = timezone.localdate()
        return self.review_date and self.review_date <= today

    @property
    def is_archived(self) -> bool:
        return self.archived

    @cached_property
    def review_date(self) -> Optional[datetime.date]:
        """ Returns date when this document is due for review based on the current version date and review frequency """
        if self.current_version_id:
            return self.current_version.review_date

    def get_absolute_url(self):
        return reverse('docs:view:doc-detail', kwargs={
            'institution_slug': self.institution.slug,
            'pk': self.pk,
        })

    @property
    def icon(self) -> str:
        if self.current_version_id:
            return self.current_version.icon
        recent_version: Version = self.versions.order_by('-created').first()
        if recent_version:
            return recent_version.icon
        # if unsure of document type, show plain text icon
        return static('images/document_icons/text.svg')

    @cached_property
    def folder_permission_rules(self) -> FolderPermissionRuleQueryset:
        return FolderPermissionRule.objects.published().for_document(self)

    @property
    def approval_config(self):
        from approvals.models import ApprovalConfig
        return ApprovalConfig.objects.published().for_document(self)

    @property
    def has_current_change_request(self) -> bool:
        """
        Returns true if there is an approved  change request for this document.
        Used to prevent new versions from being while there are checked out change requests
        """
        return bool(self.current_change_request)

    @property
    def current_change_request(self) -> Optional[DocumentChangeRequest]:
        """ Get current change request approved for document """
        return self.change_requests.published().approved().first()

    @property
    def suggestions_enabled(self) -> bool:
        """
        Returns True if suggestions are allowed to be added for this document from current change request and version states
        """
        has_pending_or_awaiting_publish_version = self.versions.published().filter(
            Q(approved=False) |
            Q(
                Q(approved=True),
                Q(Q(revision__gt=F('document__current_version__revision')) | Q(document__current_version__isnull=True))
            )
        )

        return not self.has_current_change_request and not has_pending_or_awaiting_publish_version.exists()

    def get_user_change_request(self, auditor: 'Auditor') -> Optional['DocumentChangeRequest']:
        """ Get user created change request if exists"""
        return self.change_requests.published().filter(auditor=auditor, status__in=[DOCUMENT_CHANGE_REQUEST_STATUS_PENDING, DOCUMENT_CHANGE_REQUEST_STATUS_APPROVED]).first()

    @property
    def export_url(self) -> Optional[str]:
        """ Returns export url if valid """
        if not self.current_version_id or not self.current_version.is_pdf:
            return None

        from export.exporters.pdf import DocumentExporter
        exporter: str = get_dotted_path(DocumentExporter)
        return reverse('export-view') + f"?exporter={exporter}&document_id={self.pk}"

    class Meta:
        verbose_name = _('document')
        verbose_name_plural = _('documents')
        ordering = 'institution', 'order', 'name',
        permissions = (
            ('change_document_owner', _('Change document owner')),
            ('can_export_document', _('Can export document')),
        )


class VersionQuerySet(DocumentSearchQuerysetMixin, DocumentRelationQuerySet):
    document_relation_prefix = 'document__'

    def get_new_revision_number(self) -> int:
        """
        Generates a new unused revision number
        by querying for the last revision number and incrementing it
        """
        last_revision: Optional[int] = self.order_by('revision')\
            .values_list('revision', flat=True)\
            .last()
        if last_revision is None:
            return FIRST_REVISION
        else:
            return last_revision + 1

    def populate_content(self):
        version: 'Version'
        for version in self.filter(content='').iterator():
            version.populate_content()

    def pending_review(self) -> 'VersionQuerySet':
        """ Only document newer than current version, that are not yet approved"""
        return self.filter(approved=False).filter(Q(revision__gt=F('document__current_version__revision')) | Q(document__current_version__isnull=True))

    def pending_publishing(self) -> 'VersionQuerySet':
        """ Only document newer than current version, that are not yet published"""
        return self.filter(approved=True).filter(
            Q(revision__gt=F('document__current_version__revision')) | Q(document__current_version__isnull=True)
        )

    @property
    def contributors(self) -> AuditorQueryset:
        return Auditor.objects.published().filter(pk__in=self.values_list('contributors', flat=True))

    def for_user(self, user: User) -> 'VersionQuerySet':
        if not user.has_perm('megdocs.approve_institution_versions'):
            documents: DocumentQuerySet = Document.objects.for_user(user)
            return self.filter(
                Q(creator=user.auditor) |
                Q(reviewer=user.auditor) |
                Q(contributors__in=[user.auditor]) |
                Q(pk__in=documents.values_list('current_version', flat=True))
            )
        return self

    def waiting_for_user_approval(self, user: User) -> 'VersionQuerySet':
        """
        Get a queryset of those versions that the user can see in the My Review tab.
        """
        return self.filter(approved=False).filter(Q(reviewer=user.auditor) | Q(contributors=user.auditor))

    def for_categories(self, categories: Iterable['DocumentCategory']):
        return self.filter(document__category__in=categories)


class Version(BaseModel):
    creation_date = models.DateField(verbose_name=_('Document creation date'), default=datetime.date.today)
    version_name = models.CharField(verbose_name=_('version name'), blank=True, max_length=10, help_text=_('Optional version name that could be used instead of the automatically-assigned version'))
    document = models.ForeignKey(to='megdocs.Document', verbose_name=_('document'), on_delete=CASCADE, related_name='versions')
    revision = models.PositiveIntegerField(verbose_name=_('revision'), validators=[MinValueValidator(FIRST_REVISION)], default=FIRST_REVISION)
    creator = models.ForeignKey(verbose_name=_('creator'), to='megforms.Auditor', related_name='created_documents', on_delete=PROTECT)
    reviewer = models.ForeignKey(verbose_name=_('reviewer'), to='megforms.Auditor', related_name='documents_for_review', on_delete=SET_NULL, blank=False, null=True)
    contributors = models.ManyToManyField(verbose_name=_('contributors'), to='megforms.Auditor', help_text=_('Selected users will be able to contribute to the document review with their comments. Comments will not be displayed to the end user once the document is approved'), blank=True)
    file = models.FileField(verbose_name=_('file'), upload_to=sanitize_filename('megdocs/documents/'), validators=[FileExtensionValidator(allowed_extensions=ALLOWED_DOCUMENT_EXTENSIONS)])
    source = models.FileField(verbose_name=_('word version'), upload_to=sanitize_filename('megdocs/documents/'), validators=[FileExtensionValidator(allowed_extensions=ALLOWED_SOURCE_DOCUMENT_EXTENSIONS)], help_text=_("Editable version of the document"), blank=True, null=True)
    approved = models.BooleanField(verbose_name=_('approved'), help_text=_('Whether the reviewer has approved this version for publication.'), default=False)
    content = models.TextField(verbose_name=_('content'), help_text=_('content of the attached file'), blank=True)
    summary = models.TextField(verbose_name=_('revision summary'), help_text=_('Brief summary of the current revision. i.e Why is there a new version of the document'), blank=True, null=True)
    generic_comments = GenericRelation(to='comments.Comment', related_query_name='document_versions')
    resets_checkbox = models.BooleanField(verbose_name=_('resets checkboxes'), default=False, blank=True, help_text=_("If the document has checkboxes, enable this option if users need to check the boxes again after this version is published. Leave unchecked if this version does not introduce changes that requrie reader' re-acknowledgement."))

    objects = VersionQuerySet.as_manager()

    @property
    def version(self) -> str:
        """
        Property holding the proper version. It returns the version name if set otherwise it returns revision
        """
        return self.version_name or f'v{self.revision}'

    def __str__(self):
        return f"{self.document} {self.version}"

    def __gt__(self, other: 'Version'):
        return self.revision > other.revision

    def __lt__(self, other: 'Version'):
        return self.revision < other.revision

    def get_approval_display(self):
        from approvals.models import VersionApprovalConfig
        return str(VersionApprovalConfig(self))

    def clean_fields(self, exclude=None):
        if exclude is None:
            exclude = []
        if 'version_name' not in exclude and self.version_name and self.document_id and self.document.versions.filter(version_name=self.version_name, publish=True).exists():
            raise ValidationError({'version_name': _("This document already has version {version_name}. Please enter a unique version number for the new version.").format(version_name=self.version_name)})
        return super().clean_fields(exclude)

    def populate_content(self, save=True, **kwargs):
        """
        Read file contents into content field.
        Replace null (0x00) characters which are not accepted by db.
        Encode to utf-8 to handle ascii characters and convert back to string.
        """
        if not self.is_pdf:
            return
        log_debug(f'Extracting text from {self}')
        self.content = extract_text(self.file.path, **kwargs).replace("\x00", "\uFFFD")
        log_debug(f"Text extraction complete. Length: {len(self.content)}")
        if save:
            self.save(update_fields=['content'])

    def can_comment(self, auditor: Auditor):
        """
        Whether given user can comment on this version
        Note: this method only checks model relation, it does not verify permissions
        """
        return auditor.pk in (self.reviewer_id, self.creator_id) or auditor in self.contributors.all()

    @property
    def review_date(self) -> Optional[datetime.date]:
        """ Returns date when this document version is due for review based on the current version date and review frequency """
        if self.document.review_interval:
            return self.creation_date + self.document.review_interval

    @property
    def can_show_diff(self) -> bool:
        """
        Whether diff fo this version can be shown
        Depends on content size: if there's no content, or content is too large to render efficiently, diff cannot be shown
        """
        return 0 < len(self.content) < 1_000_000

    @property
    def published(self) -> bool:
        """ Tells whether this is the current published version of the document"""
        return self.document.current_version_id == self.pk

    @property
    def extension(self) -> str:
        name, extension = os.path.splitext(self.file.name)
        return extension.replace(".", "")

    @property
    def is_pdf(self) -> bool:
        return self.extension == EXTENSION_PDF

    @property
    def is_image(self) -> bool:
        return self.extension in EXTENSIONS_IMAGE

    @property
    def icon(self):
        if self.is_pdf:
            return static('images/document_icons/pdf.svg')
        elif self.is_image:
            return static('images/document_icons/image.svg')
        elif self.extension in EXTENSIONS_MS_WORD:
            return static('images/document_icons/word.svg')
        elif self.extension in EXTENSIONS_MS_EXCEL:
            return static('images/document_icons/excel.svg')

    @property
    def file_url(self) -> str:
        return create_model_field_url(self, 'file', Path(self.file.name).name)

    @property
    def source_file_url(self) -> str:
        return create_model_field_url(self, 'source', Path(self.source.name).name)

    class Meta:
        verbose_name = _('document version')
        verbose_name_plural = _('document versions')
        unique_together = (
            ('document', 'revision'),
        )
        ordering = 'document', 'revision',
        permissions = (
            ('approve_version', _('Approve document version')),
            ('approve_institution_versions', _('Approve all document versions in institution')),
        )


class FolderQuerySet(BaseQuerySet, TreeQuerySet):
    def search(self, string: str):
        pks = self.annotate(search=SearchVector('name', 'description')).order_by() \
            .filter(search=string).values_list('pk', flat=True)
        return self.filter(pk__in=pks)

    def for_wards(self, wards: Iterable['Ward']):
        return self.filter(wards__in=wards).get_descendants(include_self=True)

    def annotate_documents_count(self, documents_qs: Optional[DocumentQuerySet] = None) -> FolderQuerySet:
        """
        Annotate descendant documents count

        :param documents_qs: filtered documents queryset to use for count annotation
        :return: FolderQuerySet with "documents_count" attributed annotated
        """
        if not documents_qs:
            documents_qs = Document.objects.published()

        descendants_subquery = self.filter(
            tree_id=models.OuterRef('tree_id'),
            lft__gte=models.OuterRef('lft'),
            rght__lte=models.OuterRef('rght'),
        ).values('id')

        return self.alias(
            descendants_ids=models.Subquery(descendants_subquery, output_field=ArrayField(models.IntegerField()))
        ).annotate(
            documents_count=SubqueryCount(
                documents_qs.filter(folder_id__in=models.OuterRef('descendants_ids'))
            ),
        )


class Folder(BaseModel, MPTTModel):
    name = models.CharField(verbose_name=_('name'), max_length=100)
    description = models.TextField(verbose_name=_('description'), blank=True)
    owner = models.ForeignKey(verbose_name=_('owner'), to='megforms.Auditor', related_name='owned_folders', on_delete=PROTECT)
    parent = TreeForeignKey('self', verbose_name=_('parent'), related_name='sub_folders', on_delete=CASCADE, null=True, blank=True)
    institution = models.ForeignKey(verbose_name=_('institution'), to='megforms.Institution', related_name='folders', on_delete=CASCADE)
    wards = models.ManyToManyField(verbose_name=_('wards'), to='megforms.Ward', related_name='folders', blank=True)

    objects = FolderQuerySet.as_manager()

    class MPTTMeta:
        order_insertion_by = ['name']

    class Meta:
        verbose_name = _('folder')
        verbose_name_plural = _('folders')

    def __str__(self):
        return self.name

    @cached_property
    def ancestors(self) -> List[str]:
        return [i.id for i in self.get_ancestors(include_self=True)]

    @cached_property
    def indentation_levels(self) -> int:
        return self.get_level()

    @cached_property
    def initial(self):
        return dict(name=self.name, description=self.description, parent=self.parent)

    @cached_property
    def immediate_sub_folders(self):
        return Folder.objects.filter(publish=True, parent=self)

    @property
    def descendant_documents(self):
        return Document.objects.published().filter(folder__in=self.get_descendants(include_self=True))

    @cached_property
    def descendant_document_count(self):
        return self.descendant_documents.count()

    @cached_property
    def indented_name(self):
        return "{} {}".format('---' * self.get_level(), self.name)


class Bookmark(BaseModel):
    user = models.ForeignKey(to=settings.AUTH_USER_MODEL, verbose_name=_('user'), on_delete=CASCADE, related_name='bookmarks')
    document = models.ForeignKey(to='megdocs.Document', verbose_name=_('document'), on_delete=CASCADE, related_name='bookmarks')

    objects = DocumentRelationQuerySet.as_manager()

    def __str__(self):
        return str(self.document)

    class Meta:
        verbose_name = _('bookmark')
        verbose_name_plural = _('bookmarks')
        unique_together = (
            ('user', 'document'),
        )


class FolderPermissionRuleQueryset(BaseQuerySet):
    def search(self, string: str):
        pks = self.annotate(search=SearchVector('name', 'folders__name', 'users__username', 'teams__name', 'permissions__codename')).order_by() \
            .filter(search=string).values_list('pk', flat=True)
        return self.filter(pk__in=pks)

    def folders(self, user: User = None, folder: Folder = None):
        """
        Returns all folders related to the rule.
        If rule folders are None, returns all folders within the institution.
        """
        folders = Folder.objects.filter(publish=True, pk__in=self.values_list('folders', flat=True))
        institution_ids = self.values_list('institution', flat=True)
        folders = folders if folders else Folder.objects.filter(publish=True, institution_id__in=institution_ids)
        if user:
            if user.is_superuser:
                folders = Folder.objects.filter(publish=True, institution_id__in=institution_ids)
            else:
                folders = Folder.objects.filter(owner=user.auditor, publish=True, institution_id__in=institution_ids) | folders
        if folder:
            return Folder.objects.filter(pk=folder.pk, publish=True, institution_id__in=institution_ids) | folders
        return folders

    def for_document(self, document: Document):
        """
        Rules for a given document.
        Returns all rules applied to all parent folders of the document.
        If the document doesn't have a folder, then an empty queryset is returned.

        :param document: The document.

        :returns: A queryset of folder permission rules.
        """
        if document.folder_id:
            return self.filter(folders__in=document.folder.get_ancestors(include_self=True).published())
        return self.none()


class FolderPermissionRule(BaseModel):
    name = models.CharField(verbose_name=_('name'), max_length=70)
    folders = models.ManyToManyField(to=Folder, verbose_name=_('folders'), related_name='folder_permission_rules')
    users = models.ManyToManyField(to=settings.AUTH_USER_MODEL, verbose_name=_('users'), related_name='folder_permission_rules')
    teams = models.ManyToManyField(to='megforms.Team', verbose_name=_('teams'), related_name='folder_permission_rules')
    permissions = models.ManyToManyField(Permission, verbose_name=_('permissions'), related_name='folder_permission_rules', limit_choices_to=Q(content_type__app_label="megdocs", codename__in=[
        'add_folder', 'view_folder', 'change_folder', 'delete_folder',
        'add_document', 'view_document', 'change_document', 'delete_document',
        'add_version', 'view_version', 'change_version', 'delete_version', 'approve_version',
    ]))
    owner = models.ForeignKey(to='megforms.Auditor', verbose_name=_('owner'), on_delete=SET_NULL, null=True, related_name='owned_folder_permission_rules')
    institution = models.ForeignKey(to='megforms.Institution', verbose_name=_('institution'), null=True, related_name='folder_permission_rules', on_delete=CASCADE)

    objects = FolderPermissionRuleQueryset.as_manager()

    def __str__(self):
        return self.name

    @cached_property
    def role_index(self):
        code_names = sorted(self.permissions.values_list("codename", flat=True))
        if code_names == MANAGER_CODENAMES:
            return 0
        elif code_names == REVIEWER_CODENAMES:
            return 1
        elif code_names == VIEWER_CODENAMES:
            return 2

    @cached_property
    def role(self):
        for role_index, role_name in FOLDER_PERMISSION_RULE_ROLE_CHOICES:
            if role_index == self.role_index:
                return role_name


class DocumentLink(BaseModel):
    name = models.CharField(verbose_name=_('name'), max_length=70)
    url = models.URLField(verbose_name=_('URL'))
    document = models.ForeignKey(to='megdocs.Document', verbose_name=_('document'), on_delete=CASCADE, related_name='links')

    objects = DocumentRelationQuerySet.as_manager()

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = _('document link')
        verbose_name_plural = _('document links')


class VersionApprovalQuerySet(BaseQuerySet):
    @property
    def auditors(self) -> AuditorQueryset:
        return Auditor.objects.filter(pk__in=self.values_list('reviewer_id'))

    def approved(self):
        return self.filter(status=VERSION_APPROVAL_STATUS_APPROVED)

    def declined(self):
        return self.filter(status=VERSION_APPROVAL_STATUS_DECLINED)


class VersionApproval(BaseModel):
    version = models.ForeignKey(to='megdocs.Version', verbose_name=_('document version'), db_index=True, on_delete=models.CASCADE)
    reviewer = models.ForeignKey(to='megforms.Auditor', verbose_name=_('reviewer'), on_delete=models.CASCADE)
    status = models.IntegerField(
        verbose_name=_('status'),
        choices=VERSION_APPROVAL_STATUS_CHOICES,
        default=VERSION_APPROVAL_STATUS_APPROVED,
    )
    reason = models.TextField(verbose_name=_('reason for decline'), blank=True)
    step = models.IntegerField(_('approval step'), default=0)

    objects = VersionApprovalQuerySet.as_manager()

    def __str__(self):
        if self.status == VERSION_APPROVAL_STATUS_DECLINED:
            return f"{self.version} declined by {self.reviewer} on {self.created}"
        return f"{self.version} approved by {self.reviewer} on {self.created}"

    def get_step_display(self) -> str:
        return str(self.step + 1)

    class Meta:
        verbose_name = _('version approval')
        verbose_name_plural = _('version approvals')
        unique_together = (
            ('reviewer', 'version', 'step'),
        )


class DocumentCheckbox(BaseModel):
    """
    Defines per-user checkbox to be displayed on document page to record understading / having read the document
    As per :task:`25521`
    """
    document = models.ForeignKey(to='megdocs.Document', verbose_name=_("document"), on_delete=models.CASCADE, related_name='checkboxes')
    label = models.CharField(verbose_name=_('checkbox label'), max_length=100, help_text=_("label displayed on the checkbox"))
    help_text = models.CharField(verbose_name=_('help text'), max_length=200, help_text=_("more details description, will be displayed as a tooltip on the checkbox"), blank=True)
    required = models.BooleanField(verbose_name=_('required'), blank=True, help_text=_("if checkbox is mandatory, the user will be warned before leaving the page that it should be checked"))

    def __str__(self) -> str:
        return self.label

    def is_checked(self, version: Version, user: Auditor) -> bool:
        return self.states.filter(version=version, user=user).exists()

    class Meta:
        verbose_name = _("document checkbox")
        verbose_name_plural = _("document checkboxes")


class DocumentCheckboxState(BaseModel):
    """
    Marks that user has checked the DocumentCheckbox for a given document version
    """
    checkbox = models.ForeignKey(to='megdocs.DocumentCheckbox', on_delete=models.CASCADE, verbose_name=_("checkbox"), related_name='states')
    version = models.ForeignKey(to='megdocs.Version', on_delete=models.CASCADE, verbose_name=_("version"), related_name='document_checkbox_states')
    user = models.ForeignKey(to='megforms.Auditor', on_delete=models.CASCADE, verbose_name=_("user"), related_name='document_checkbox_states')

    def __str__(self):
        return f"{self.user} - {self.checkbox}"

    def clean_fields(self, exclude=None):
        if exclude is None:
            exclude = []
        if 'version' not in exclude and self.version.document_id != self.checkbox.document_id:
            raise ValidationError({'version': _("Selected version does not match selected checkbox")})
        return super().clean_fields(exclude)

    def copy_to(self, version: Version) -> 'DocumentCheckboxState':
        """
        clears pk and updates version in this object and returns it.
        Note that the instance is mutated rather than a new one being returned.
        """
        self.pk = None
        self.version = version
        return self

    class Meta:
        verbose_name = _("document checkbox state")
        verbose_name_plural = _("document checkbox states")
        unique_together = (
            ('version', 'user', 'checkbox'),
        )
        index_together = (
            ('version', 'user'),
        )


class DocumentCategoryQuerySet(BaseQuerySet):
    def for_institution(self, institution):
        """ Returns audit forms of the selected institutions """
        return self.filter(
            Q(institution=institution) |
            (Q(level=LEVEL_GROUP) & Q(institution__group_id=institution.group_id) & Q(institution__group__isnull=False))
        )


class DocumentCategory(BaseModel):
    name = models.CharField(verbose_name=_('name'), max_length=100)
    institution = models.ForeignKey(verbose_name=_('institution'), to='megforms.Institution', related_name='document_categories', on_delete=CASCADE)
    level = models.CharField(verbose_name=_('level'), help_text=_('Whether this category is accessible only for the above institution, or its group'), max_length=32, choices=FORM_LEVEL_CHOICES, default=LEVEL_INSTITUTION)

    objects = DocumentCategoryQuerySet.as_manager()

    def __str__(self):
        return self.name

    class Meta:
        ordering = 'order', 'pk',
        verbose_name = _('document category')
        verbose_name_plural = _('document categories')


class DocumentChangeRequestQuerySet(DocumentSearchQuerysetMixin, BaseQuerySet):
    document_relation_prefix = 'document__'

    def pending(self):
        return self.filter(status=DOCUMENT_CHANGE_REQUEST_STATUS_PENDING)

    def approved(self):
        return self.filter(status=DOCUMENT_CHANGE_REQUEST_STATUS_APPROVED)

    def declined(self):
        return self.filter(status=DOCUMENT_CHANGE_REQUEST_STATUS_DECLINED)

    def for_new(self):
        return self.filter(type=CHANGE_REQUEST_ACTION_TYPE_NEW)

    def for_edit(self):
        return self.filter(type=CHANGE_REQUEST_ACTION_TYPE_EDIT)

    def for_archive(self):
        return self.filter(type=CHANGE_REQUEST_ACTION_TYPE_ARCHIVE)

    def for_institution(self, institution: 'Institution'):
        return self.for_institutions([institution])

    def for_institutions(self, institutions: Iterable['Institution']):
        return self.filter(Q(document__institution__in=institutions) | Q(institution__in=institutions))

    def for_user(self, user: User):
        from accounts.utils import get_user_institutions
        qs = self.for_institutions(get_user_institutions(user))

        if user.has_perm('megdocs.view_documentchangerequest') or user.has_perm('megdocs.change_documentchangerequest'):
            # return all change requests he has access to when he has permission
            return qs.filter(Q(document__folder__in=user.auditor.allowed_folders()) | Q(document__folder=None))

        # return user own change requests when he doesn't have permission
        return qs.filter(Q(auditor=user.auditor) | Q(owner=user.auditor))

    def for_categories(self, categories: Iterable['DocumentCategory']):
        return self.filter(document__category__in=categories)


class DocumentChangeRequest(BaseModel):
    institution = models.ForeignKey(to='megforms.Institution', verbose_name=_('institution'), on_delete=CASCADE, limit_choices_to={
        'megdocs_enabled': True,
        'megdocs_change_requests': MEGDOCS_CHANGE_REQUESTS_ENABLED,
    }, related_name='change_requests')
    document = models.ForeignKey(to='megdocs.Document', verbose_name=_('document'), on_delete=CASCADE, limit_choices_to={
        'institution__megdocs_enabled': True,
        'institution__megdocs_change_requests': MEGDOCS_CHANGE_REQUESTS_ENABLED,
    }, related_name='change_requests', blank=True, null=True)
    description = models.TextField(verbose_name=_('description of change'))
    reason = models.TextField(verbose_name=_('reason of suggested change'))
    auditor = models.ForeignKey(to='megforms.Auditor', verbose_name=_('suggested by'), related_name='+', on_delete=PROTECT)
    status = models.IntegerField(
        _('request status'),
        choices=DOCUMENT_CHANGE_REQUEST_STATUS_CHOICES,
        default=DOCUMENT_CHANGE_REQUEST_STATUS_PENDING,
    )
    owner = models.ForeignKey(to='megforms.Auditor', verbose_name=_('owner'), help_text=_('Owner of the document after creation for New Document requests'), related_name='+', on_delete=PROTECT, null=True, blank=True)
    version = models.ForeignKey(to='megdocs.Version', verbose_name=_('new version that was added by this change request.'), related_name='+', on_delete=PROTECT, null=True, blank=True)
    type = models.CharField(
        verbose_name=_('action type'),
        max_length=7,
        default=CHANGE_REQUEST_ACTION_TYPE_EDIT,
        choices=CHANGE_REQUEST_ACTION_TYPES,
    )

    objects = DocumentChangeRequestQuerySet.as_manager()

    class Meta:
        ordering = 'order', 'pk',
        verbose_name = _('document change request')
        verbose_name_plural = _('document change requests')
        permissions = (
            ('can_suggest_new_document', _('Can Suggest New Documents')),
        )

    @property
    def is_new(self) -> bool:
        """
        Whether this Request is for New Documents
        """
        return self.type == CHANGE_REQUEST_ACTION_TYPE_NEW

    @property
    def is_edit(self) -> bool:
        """
        Whether this Request is for Document Updates
        """
        return self.type == CHANGE_REQUEST_ACTION_TYPE_EDIT

    @property
    def is_archive(self) -> bool:
        """
        Whether this Request is for Document Archival
        """
        return self.type == CHANGE_REQUEST_ACTION_TYPE_ARCHIVE

    @property
    def is_approved(self) -> bool:
        return self.status == DOCUMENT_CHANGE_REQUEST_STATUS_APPROVED

    @property
    def is_pending(self) -> bool:
        return self.status == DOCUMENT_CHANGE_REQUEST_STATUS_PENDING

    def can_approve_or_decline(self, auditor: 'Auditor') -> bool:
        """ If user can approve or reject this change request """
        if self.status != DOCUMENT_CHANGE_REQUEST_STATUS_PENDING:
            return False

        if self.is_new:
            return self.owner_id == auditor.pk and auditor.user.has_perm('megdocs.change_document')

        return self.document.owner_id == auditor.pk and (
            auditor.user.has_perm('megdocs.change_documentchangerequest')
        )

    def can_submit(self, auditor: 'Auditor') -> bool:
        """ If the user can submit new version via this change request"""
        return self.is_approved and self.auditor_id == auditor.pk and (
            self.is_new and auditor.user.has_perm('megdocs.can_suggest_new_document') or
            self.is_edit and auditor.user.has_perm('megdocs.add_documentchangerequest')
        ) and not auditor.user.has_perm("megdocs.change_document")

    def new_version(self, by: 'Auditor', version: 'Version') -> 'Version':
        from megdocs.tasks import parse_document_content

        with reversion.create_revision():
            reversion.set_user(by.user)
            reversion.set_comment('Upload new version file from change request')

            if self.is_new:
                self.document = Document(
                    name=version.file.name,
                    description=self.description,
                    institution=self.institution,
                    owner=self.owner,
                )
                self.document.save()

            new_version: Version = version
            new_version.document = self.document
            new_version.creator = self.auditor
            new_version.reviewer = self.document.owner
            new_version.revision = self.document.get_new_revision_number()
            new_version.save()

            self.version = new_version
            self.status = DOCUMENT_CHANGE_REQUEST_STATUS_FINISHED
            self.save()
            LogEntry.objects.log_action(
                by.user.pk,
                ContentType.objects.get_for_model(self.document).pk,
                self.document.pk,
                repr(self.document),
                CHANGE,
                change_message='Upload new version file from change request',
            )
            transaction.on_commit(lambda: parse_document_content.delay(new_version.pk))
        return new_version

    def archive(self, by: 'Auditor'):
        """ Archive current document change"""
        with reversion.create_revision():
            reversion.set_user(by.user)
            reversion.set_comment('Archive change request from change request')

            self.document.archived = True
            self.document.save()
            self.status = DOCUMENT_CHANGE_REQUEST_STATUS_FINISHED
            self.save()
            LogEntry.objects.log_action(
                by.user.pk,
                ContentType.objects.get_for_model(self.document).pk,
                self.document.pk,
                repr(self.document),
                CHANGE,
                change_message='Archive change request from change request',
            )


class DocumentUploadMetadataQuerySet(BaseQuerySet):
    def for_user(self, user: User):
        return self.for_institutions(user.auditor.institutions)


class DocumentUploadMetadata(BaseModel):
    data = models.JSONField(verbose_name=_('data'), help_text=format_html(
        _('The raw validated data parsed from the source excel file. Download the {xls_template}, fill it in with the document details, and new documents (and versions) can be created via the associated API using this metadata.'),
        xls_template=format_html(
            '<a href="https://docs.google.com/spreadsheets/d/1iojYnHosVQpK9g-o7YgmrKjHnrxE-8V6zTHT375maZA/edit?usp=sharing" target="_blank">{label}</a>',
            label=_('Excel template'),
        )
    ))
    institution = models.ForeignKey(verbose_name=_('institution'), to='megforms.Institution', on_delete=CASCADE)

    objects = DocumentUploadMetadataQuerySet.as_manager()

    class Meta:
        ordering = 'order', 'pk',
        verbose_name = _('document upload metadata')
        verbose_name_plural = _('document upload metadatas')
