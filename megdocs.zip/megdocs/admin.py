from django.contrib import admin, messages
from django.forms import ModelMultipleChoiceField, ModelChoiceField
from django.http import HttpRequest
from django.utils.translation import gettext_lazy as _

from megdocs import models
from megdocs.models import VersionQuerySet, Version, DocumentQuerySet
from megforms.admin import BaseAdmin
from megforms.models import AuditorQueryset


class VersionInlineAdmin(admin.TabularInline):
    model = models.Version
    extra = 0
    fields = 'revision', 'creator', 'reviewer', 'file', 'approved',
    show_change_link = True
    raw_id_fields = 'creator', 'reviewer',


@admin.register(models.Document)
class DocumentAdmin(BaseAdmin):
    list_display = 'name', 'owner', 'institution', 'current_version'
    search_fields = 'name', 'description',
    list_filter = (
        ('owner', admin.RelatedOnlyFieldListFilter),
        ('institution', admin.RelatedOnlyFieldListFilter),
        'publish',
        ('folder', admin.RelatedOnlyFieldListFilter),
    )
    raw_id_fields = 'owner', 'owner', 'institution', 'current_version',
    autocomplete_fields = 'leads', 'forms', 'documents', 'folder',
    inlines = VersionInlineAdmin,
    list_select_related = 'current_version__document', 'institution', 'owner__user', 'folder',
    actions = BaseAdmin.actions + ('archive_docs', 'unarchive_docs', )

    def formfield_for_foreignkey(self, db_field, request=None, **kwargs):
        field: ModelChoiceField = super().formfield_for_foreignkey(db_field, request, **kwargs)
        if db_field.name == 'category' and 'object_id' in request.resolver_match.kwargs:
            document: models.Document = models.Document.objects.get(pk=request.resolver_match.kwargs['object_id'])
            field.queryset = field.queryset.for_institution(document.institution)
        return field

    @admin.action(description=_('Archive'), permissions=('change',))
    def archive_docs(self, request: HttpRequest, qs: DocumentQuerySet):
        archived = qs.update(archived=True)
        self.message_user(request, _('successfully archived {archived} documents').format(archived=archived))

    @admin.action(description=_('Unarchive'), permissions=('change',))
    def unarchive_docs(self, request: HttpRequest, qs: DocumentQuerySet):
        unarchived = qs.update(archived=False)
        self.message_user(request, _('successfully unarchived {unarchived} documents').format(unarchived=unarchived))


@admin.register(models.Folder)
class FolderAdmin(BaseAdmin):
    list_display = 'name', 'owner', 'institution',
    raw_id_fields = 'owner', 'institution', 'parent',
    list_filter = (
        ('institution', admin.RelatedOnlyFieldListFilter),
    )
    search_fields = 'name',


@admin.register(models.Version)
class VersionAdmin(BaseAdmin):
    list_display = '__str__', 'creation_date', 'approved', 'creator', 'is_parsed',
    search_fields = 'document__name', 'content',
    raw_id_fields = 'document', 'creator', 'reviewer',
    list_filter = (
        'approved',
        'publish',
    )
    actions = BaseAdmin.actions + ('populate_content', )
    readonly_fields = 'created',
    filter_horizontal = 'contributors',
    date_hierarchy = 'created'

    def formfield_for_manytomany(self, db_field, request, **kwargs):
        field: ModelMultipleChoiceField = super().formfield_for_manytomany(db_field, request, **kwargs)
        if db_field.name == 'contributors':
            version_id: int | None = request.resolver_match.kwargs.get('object_id', None)
            qs: AuditorQueryset = field.queryset.annotate_display_name()
            if version_id:
                version = Version.objects.select_related('document__institution').get(pk=version_id)
                qs = qs.for_institution(version.document.institution)
            else:
                qs = qs.none()
            field.queryset = qs

        return field

    @admin.action(description=_('Populate content'), permissions=('change',))
    def populate_content(self, request: HttpRequest, qs: VersionQuerySet):
        version: Version
        for version in qs.iterator():
            try:
                version.populate_content()
                self.message_user(request, _('{version} content populated successfully').format(version=version))
            except Exception as e:
                self.message_user(request, _('Error populating {version}: {error}').format(version=version, error=e), level=messages.WARNING)

    @admin.display(boolean=True, description=_('parsed'))
    def is_parsed(self, obj: Version) -> bool:
        return bool(obj.content)


@admin.register(models.Bookmark)
class BookmarkAdmin(BaseAdmin):
    list_display = 'document', 'user', 'created',
    search_fields = 'document__name', 'user__username',
    raw_id_fields = 'user', 'document',


@admin.register(models.FolderPermissionRule)
class FolderPermissionRuleAdmin(BaseAdmin):
    list_display = 'name', 'institution', 'publish',
    list_filter = (
        'publish',
        ('institution', admin.RelatedOnlyFieldListFilter),
        ('permissions', admin.RelatedOnlyFieldListFilter),
    )
    search_fields = 'users__username', 'folders__name', 'teams__name',
    raw_id_fields = 'institution', 'owner',
    filter_horizontal = 'users', 'folders', 'teams', 'permissions',


@admin.register(models.DocumentLink)
class DocumentLinkAdmin(BaseAdmin):
    list_display = 'document', 'name', 'url',
    search_fields = 'document__name', 'name', 'url',
    raw_id_fields = 'document',


@admin.register(models.VersionApproval)
class VersionApprovalAdmin(BaseAdmin):
    list_display = 'reviewer', 'version', 'status', 'step', 'publish', 'created',
    raw_id_fields = 'version', 'reviewer',
    list_filter = (
        'status',
        'publish',
        ('version__document', admin.RelatedOnlyFieldListFilter),
    )
    date_hierarchy = 'created'


@admin.register(models.DocumentCheckbox)
class DocumentCheckboxAdmin(BaseAdmin):
    list_display = 'document', 'label', 'required', 'publish'
    list_editable = 'publish',
    raw_id_fields = 'document',
    search_fields = 'label', 'help_text', 'document__name',
    list_filter = 'required', 'publish',


@admin.register(models.DocumentCheckboxState)
class DocumentCheckboxStateAdmin(BaseAdmin):
    list_display = 'checkbox', 'version', 'user'
    raw_id_fields = 'checkbox', 'version', 'user',
    search_fields = 'checkbox__label', 'user__user__username',
    list_filter = (
        ('checkbox', admin.RelatedOnlyFieldListFilter),
    )


@admin.register(models.DocumentCategory)
class DocumentCategoryAdmin(BaseAdmin):
    list_display = 'name', 'institution', 'level', 'order', 'publish',
    search_fields = 'institution__name', 'name',
    raw_id_fields = 'institution',
    list_filter = 'level', 'publish'


@admin.register(models.DocumentChangeRequest)
class DocumentChangeRequestAdmin(BaseAdmin):
    list_display = 'id', 'document', 'type', 'auditor', 'status', 'version', 'publish', 'created',
    list_select_related = 'auditor', 'version',
    search_fields = 'document__institution__name', 'document__name',
    raw_id_fields = 'document', 'auditor',
    list_filter = 'type', 'status', 'publish'


@admin.register(models.DocumentUploadMetadata)
class DocumentUploadMetadataAdmin(BaseAdmin):
    list_display = 'pk', 'institution', 'publish'
    list_filter = 'institution', 'publish',
    raw_id_fields = 'institution',
