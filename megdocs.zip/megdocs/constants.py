from datetime import timedelta

from django.utils.text import format_lazy, capfirst
from django.utils.translation import gettext_lazy as _

# Number of items we're showing on page (number of documents, versions etc) before breaking list into multiple pages.
PAGE_SIZE = 50

#: Permission required to be a reviewer
REVIEWER_PERMISSION = 'megdocs.approve_version'

REVIEW_FREQUENCY_ANNUAL = timedelta(365)
REVIEW_FREQUENCY_SEMI_ANNUAL = REVIEW_FREQUENCY_ANNUAL / 2
REVIEW_FREQUENCY_QUARTERLY = REVIEW_FREQUENCY_ANNUAL / 4
REVIEW_FREQUENCY_TWO_YEARS = REVIEW_FREQUENCY_ANNUAL * 2
REVIEW_FREQUENCY_THREE_YEARS = REVIEW_FREQUENCY_ANNUAL * 3
REVIEW_FREQUENCY_FOUR_YEARS = REVIEW_FREQUENCY_ANNUAL * 4
REVIEW_FREQUENCY_FIVE_YEARS = REVIEW_FREQUENCY_ANNUAL * 5

REVIEW_FREQUENCY_CHOICES = (
    (REVIEW_FREQUENCY_FIVE_YEARS, _('5 years')),
    (REVIEW_FREQUENCY_FOUR_YEARS, _('4 years')),
    (REVIEW_FREQUENCY_THREE_YEARS, _('3 years')),
    (REVIEW_FREQUENCY_TWO_YEARS, _('2 years')),
    (REVIEW_FREQUENCY_ANNUAL, _('annual')),
    (REVIEW_FREQUENCY_SEMI_ANNUAL, _('semi-annual')),
    (REVIEW_FREQUENCY_QUARTERLY, _('quarterly')),
)

REVIEW_INTERVAL_REMIND_BEFORE = timedelta(days=30)

MANAGER = _('Manager')
REVIEWER = _('Reviewer')
VIEWER = _('Viewer')

MANAGER_CODENAMES = [
    'add_comment',
    'add_document',
    'add_folder',
    'add_folderpermissionrule',
    'add_version',
    'approve_version',
    'change_document',
    'change_folder',
    'change_folderpermissionrule',
    'change_version',
    'delete_document',
    'delete_folder',
    'delete_folderpermissionrule',
    'delete_version',
    'view_comment',
    'view_document',
    'view_folder',
    'view_folderpermissionrule',
    'view_version',
]

MANAGE_PERMS = [
    'megdocs.add_document',
    'megdocs.change_document',
    'megdocs.view_version',
    'megdocs.add_version',
    'megdocs.change_version',
    'megdocs.approve_version',
    'megdocs.add_folder',
    'megdocs.change_folder',
    'comments.add_comment',
]


REVIEWER_CODENAMES = [
    'add_comment',
    'approve_version',
    'view_comment',
    'view_document',
    'view_folder',
    'view_folderpermissionrule',
    'view_version'
]

VIEWER_CODENAMES = [
    'view_comment',
    'view_document',
    'view_folder',
    'view_folderpermissionrule',
    'view_version',
]

FOLDER_PERMISSION_RULE_ROLE_CHOICES = (
    (0, MANAGER),
    (1, REVIEWER),
    (2, VIEWER),
)

FOLDER_PERMISSION_CODENAMES_MAP = {
    0: MANAGER_CODENAMES,
    1: REVIEWER_CODENAMES,
    2: VIEWER_CODENAMES
}

FOLDER_PERMISSION_APPNAMES = ["megdocs", "comments"]

EXTENSION_PDF = 'pdf'
EXTENSIONS_MS_WORD = 'docx', 'dot', 'dotx',
EXTENSIONS_MS_EXCEL = 'xls', 'xlsm', 'xlsx', 'xlt', 'xltm',
EXTENSIONS_IMAGE = 'jpg', 'jpeg', 'png',
ALLOWED_DOCUMENT_EXTENSIONS = EXTENSION_PDF, *EXTENSIONS_MS_WORD, *EXTENSIONS_MS_EXCEL, *EXTENSIONS_IMAGE,
ALLOWED_SOURCE_DOCUMENT_EXTENSIONS = 'doc', 'docx',

DOCUMENT_FILTER_DATE_MODIFIED = 'modified'
DOCUMENT_FILTER_DATE_NEXT_REVIEW = 'next_review'
DOCUMENT_FILTER_DATE_CHOICES = (
    (DOCUMENT_FILTER_DATE_MODIFIED, _('Modified Date')),
    (DOCUMENT_FILTER_DATE_NEXT_REVIEW, _('Next Review Date')),
)

DOCUMENT_LEAD_CLINICAL_LEAD = 'ward'

DOCUMENT_LEAD_VARIANTS = {
    DOCUMENT_LEAD_CLINICAL_LEAD: {
        'singular': _('clinical lead'),
        'plural': _('clinical leads'),
    },
}

DOCUMENT_LEAD_CHOICES = sorted((value, capfirst(format_lazy('{singular}, {plural}', **spec))) for value, spec in DOCUMENT_LEAD_VARIANTS.items())

DOCUMENT_SEARCH_TEXT_TITLE = 'TITLE'
DOCUMENT_SEARCH_TEXT_CONTENT = 'CONTENT'
DOCUMENT_SEARCH_TEXT_TAGS = 'TAGS'

DOCUMENT_SEARCH_TEXT_TYPES = (
    (DOCUMENT_SEARCH_TEXT_TITLE, _('Title')),
    (DOCUMENT_SEARCH_TEXT_CONTENT, _('Content')),
    (DOCUMENT_SEARCH_TEXT_TAGS, _('Tags')),
)

DOCUMENT_CHANGE_REQUEST_STATUS_PENDING = 0
DOCUMENT_CHANGE_REQUEST_STATUS_APPROVED = 1
DOCUMENT_CHANGE_REQUEST_STATUS_FINISHED = 2
DOCUMENT_CHANGE_REQUEST_STATUS_DECLINED = 3

DOCUMENT_CHANGE_REQUEST_STATUS_CHOICES = (
    (DOCUMENT_CHANGE_REQUEST_STATUS_PENDING, _('Pending')),
    (DOCUMENT_CHANGE_REQUEST_STATUS_APPROVED, _('Approved')),
    (DOCUMENT_CHANGE_REQUEST_STATUS_FINISHED, _('Finished')),
    (DOCUMENT_CHANGE_REQUEST_STATUS_DECLINED, _('Declined')),
)

CHANGE_REQUEST_ACTION_TYPE_NEW = 'NEW'
CHANGE_REQUEST_ACTION_TYPE_EDIT = 'EDIT'
CHANGE_REQUEST_ACTION_TYPE_ARCHIVE = 'ARCHIVE'

CHANGE_REQUEST_ACTION_TYPES = (
    (CHANGE_REQUEST_ACTION_TYPE_NEW, _('New document')),
    (CHANGE_REQUEST_ACTION_TYPE_EDIT, _('Edit document')),
    (CHANGE_REQUEST_ACTION_TYPE_ARCHIVE, _('Archive document')),
)

DOCUMENT_METADATA_IMPORT_COLUMNS = "name", "folder_path", "owner", "tags", "review_interval", "required_approvals", \
    "archived", "forms", "documents", "category", "filename", "word_filename", "creator", "creation_date", \
    "reviewer", "contributors", "approved", "revision", "version_name", "summary", "make_current",
