$(document).ready(function () {
    $('#id_owners').multiselect({
        nonSelectedText: gettext('Select owners...'),
    });
});