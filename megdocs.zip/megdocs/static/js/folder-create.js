$(document).ready(function () {
    $('#id_parent').multiselect({
        enableCaseInsensitiveFiltering: true,
    });
});
