from typing import List, Optional

from django.contrib.auth.mixins import PermissionRequiredMixin
from django.contrib.auth.models import Permission, User
from django.db.models import Q
from django.shortcuts import get_object_or_404

from megdocs.models import Folder, Document, Version, FolderPermissionRule


class FolderPermMixinBase(PermissionRequiredMixin):
    """ Base class to check user folder permissions"""

    def get_folder_permission_required(self) -> List[str]:
        valid = [
            'megdocs.add_document', 'megdocs.change_document', 'megdocs.delete_document', 'megdocs.view_document',
            'megdocs.view_version', 'megdocs.add_version', 'megdocs.change_version', 'megdocs.delete_version',
            'megdocs.approve_version', 'megdocs.view_folder', 'megdocs.add_folder', 'megdocs.change_folder',
            'megdocs.delete_folder',
        ]
        base_permissions = self.get_permission_required()
        return [permission.replace("megdocs.", "") for permission in base_permissions if permission in valid]

    def check_folder_permissions_by_pk(self, pk) -> bool:
        return self.check_folder_permissions(get_object_or_404(Folder.objects.published(), pk=pk))

    def check_folder_permissions(self, folder: Folder) -> bool:
        if hasattr(self.request.user, "auditor"):
            if folder.owner == self.request.user.auditor or self.request.user.is_superuser:
                return True

            required_permissions = self.get_folder_permission_required()
            folder_permissions = FolderPermissionRule.objects.published().filter(Q(folders__in=folder.get_ancestors(include_self=True)) | Q(folders=None), institution=self.institution)

            # if no folder permissions for folder, check user global permissions
            if not folder_permissions.exists():
                return self.check_global_permissions(required_permissions, self.request.user)

            # folder permission rule admins need access to all folders in order to manage rules.
            if self.request.user.has_perms([
                'megdocs.view_folderpermissionrule',
                'megdocs.add_folderpermissionrule',
                'megdocs.change_folderpermissionrule',
                'megdocs.delete_folderpermissionrule',
            ]):
                return True

            return folder_permissions\
                .filter(permissions__in=Permission.objects.filter(codename__in=required_permissions, content_type__app_label="megdocs"))\
                .filter(Q(teams__auditors=self.request.user.auditor) | Q(users=self.request.user))\
                .exists()
        return False

    def check_global_permissions(self, permissions: List[str], user: User):
        """
        Users are permitted to view any unprotected document, folder or version within their
        institution, provided they have the required global permissions.
        """
        if not permissions:
            return False
        return user.has_perms(["megdocs.{0}".format(permission) for permission in permissions])

    def get_url_pk(self, key: Optional[str] = "folder") -> str:
        return self.request.resolver_match.kwargs.get(key)


class FolderPermPOSTParentMixin(FolderPermMixinBase):
    """Check user folder permission against a create folder request"""
    def has_permission(self):
        if self.request.POST and self.request.POST.get("parent"):
            if not self.check_folder_permissions_by_pk(self.request.POST["parent"]):
                return False

        return super().has_permission()


class FolderPermPOSTDocMixin(FolderPermMixinBase):
    """Check user folder permission against an create document request"""
    def has_permission(self):
        if self.request.POST and self.request.POST.get("folder"):
            if not self.check_folder_permissions_by_pk(self.request.POST["folder"]):
                return False

        return super().has_permission()


class FolderPermUpdateDocMixin(FolderPermMixinBase):
    """Check user folder permission against an update document request"""
    def get_folder_permission_required(self) -> List[str]:
        if self.request.POST.get('save') == 'remove':
            return ["delete_document"]
        return super().get_folder_permission_required()

    def has_permission(self):
        if self.request.POST and self.request.POST.get("folder"):
            if not self.check_folder_permissions_by_pk(self.request.POST["folder"]):
                return False

        document = get_object_or_404(Document.objects.published(), pk=self.get_url_pk(key="pk"))
        if document.folder:
            if not self.check_folder_permissions(document.folder):
                return False

        return super().has_permission()


class FolderPermUpdateFolderMixin(FolderPermMixinBase):
    """Check user folder permission against an update folder request"""

    def get_folder_permission_required(self) -> List[str]:
        if self.request.POST.get('save') == 'remove':
            return ["delete_folder"]
        return super().get_folder_permission_required()

    def has_permission(self):
        if self.request.POST and self.request.POST.get("parent"):
            if not self.check_folder_permissions_by_pk(self.request.POST["parent"]):
                return False

        if not self.check_folder_permissions_by_pk(self.get_url_pk(key="pk")):
            return False

        return super().has_permission()


class FolderPermViewFolderMixin(FolderPermMixinBase):
    """Check user folder permission against a folder's url"""
    def has_permission(self):
        pk = self.get_url_pk(key="folder")
        if pk:
            if not self.check_folder_permissions_by_pk(pk):
                return False

        return super().has_permission()


class FolderPermDocMixin(FolderPermMixinBase):
    """Check user folder permission against a document's url"""
    def has_permission(self):
        folder = get_object_or_404(Document.objects.published(), pk=self.get_url_pk(key="pk")).folder
        if folder:
            if not self.check_folder_permissions(folder):
                return False

        return super().has_permission()


class FolderPermDocVersionMixin(FolderPermMixinBase):
    """Check user folder permission against a document version's url"""
    def has_permission(self):
        folder = get_object_or_404(Version.objects.published(), pk=self.get_url_pk(key="pk")).document.folder
        if folder:
            if not self.check_folder_permissions(folder):
                return False

        return super().has_permission()
