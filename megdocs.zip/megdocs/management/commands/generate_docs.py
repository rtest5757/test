import itertools
import os
from argparse import ArgumentParser

from django.core.management import BaseCommand

from megdocs.scripts.create_documents import create_documents, PDF_DIR
from megforms.models import Institution


class Command(BaseCommand):
    def add_arguments(self, parser: ArgumentParser):
        super().add_arguments(parser)
        parser.add_argument('institution_id', type=int, choices=Institution.objects.values_list('pk', flat=True))
        parser.add_argument('num_documents', type=int)

    def handle(self, *args, institution_id, num_documents, **options):
        institution: Institution = Institution.objects.get(pk=institution_id)
        self.stdout.write(f"Generating {num_documents} documents for {institution}...")
        pdfs = itertools.cycle(os.path.join(PDF_DIR, f) for f in os.listdir(PDF_DIR))
        create_documents(institution, itertools.islice(pdfs, num_documents))
        self.stdout.write(f"Generated {num_documents}. Total: {institution.documents.count()}")
