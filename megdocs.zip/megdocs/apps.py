from django.apps import AppConfig
from django.conf import settings
from django.contrib.auth import get_user_model
from django.db import transaction
from django.db.models.signals import post_save
from django.utils.translation import gettext_lazy as _, gettext


class MegDocsApp(AppConfig):
    name = 'megdocs'
    verbose_name = _('MEG Docs')

    def ready(self):
        from megdocs.models import Document
        super().ready()
        post_save.connect(self.on_document_updated, Document, dispatch_uid='MegDocsApp')
        post_save.connect(self.on_auditor_saved, get_user_model(), dispatch_uid='MegDocsApp')

    def on_document_updated(self, sender, instance, **kwargs):
        """ When a document is updated, update document's forms schema_modified date """
        if not instance.current_version:
            return
        transaction.on_commit(instance.forms.update_schema_modified)

    def on_auditor_saved(self, sender, instance, **kwargs):
        """ When auditor account is deactivated, send e-mail to notify document managers that documents needs to be reassigned """
        from megforms.models import Auditor
        from django.contrib.auth.models import User
        from megdocs.models import DocumentQuerySet
        from megforms.models import Institution, AuditorQueryset
        from emails.utils import send_mail_template
        instance: User
        if not instance.is_active and hasattr(instance, 'auditor'):
            auditor: Auditor = instance.auditor
            documents: DocumentQuerySet = auditor.owned_documents.published()
            institution: Institution
            for institution in Institution.objects.filter(pk__in=documents.values_list('institution_id', flat=True)):
                auditors: AuditorQueryset = (Auditor.objects.for_institution(institution).with_email_address()
                                             .active_users().with_permission('megdocs.change_document_owner'))

                send_mail_template(
                    gettext('Document owner account has been deactivated'),
                    'document_owner_deactivated_notification',
                    settings.DEFAULT_FROM_EMAIL,
                    addr_to=auditors.values_list('user__email', flat=True),
                    context={
                        'deactivated_auditor': auditor,
                        'documents': documents.filter(institution=institution),
                        'institution': institution,
                    },
                )
