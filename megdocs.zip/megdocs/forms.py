import datetime
from functools import cached_property
from pathlib import Path
from typing import Sequence, List, Optional, Iterable, Iterator, Tuple, Union

from bootstrap_daterangepicker.fields import DateRangeField
from bootstrap_daterangepicker.widgets import DateRangeWidget
from django import forms
from django.conf import settings
from django.contrib.auth.models import User, Permission
from django.core.exceptions import ValidationError
from django.core.files.uploadedfile import UploadedFile
from django.core.validators import FileExtensionValidator
from django.db import transaction
from django.db.models import Q, QuerySet
from django.forms import ChoiceField, DateInput, HiddenInput
from django.utils import timezone
from django.utils.translation import gettext_lazy as _, gettext

from approvals.models import VersionApprovalConfig
from audit_builder.widgets import MultiFileClearableInput, MultiFileFormField
from megdocs.constants import REVIEW_FREQUENCY_CHOICES, FOLDER_PERMISSION_CODENAMES_MAP, \
    FOLDER_PERMISSION_RULE_ROLE_CHOICES, FOLDER_PERMISSION_APPNAMES, ALLOWED_DOCUMENT_EXTENSIONS, \
    DOCUMENT_FILTER_DATE_CHOICES, DOCUMENT_FILTER_DATE_MODIFIED, DOCUMENT_FILTER_DATE_NEXT_REVIEW, \
    ALLOWED_SOURCE_DOCUMENT_EXTENSIONS, DOCUMENT_SEARCH_TEXT_TYPES, CHANGE_REQUEST_ACTION_TYPE_ARCHIVE
from megdocs.models import (
    Document, Version, DocumentQuerySet, FIRST_REVISION, Folder, VersionQuerySet,
    FolderPermissionRule, FolderPermissionRuleQueryset, DocumentLink, DocumentCategory, DocumentCategoryQuerySet,
    DocumentChangeRequest, DocumentChangeRequestQuerySet
)
from megdocs.tasks import parse_document_content, share_document
from megdocs.utils import get_document_reviewer_choices
from megforms.calendar.utils import date_range_choices
from megforms.models import Auditor, Institution, AuditorQueryset, Team, Ward, AuditForm, \
    InstitutionQuerySet
from megforms.tooltips import TooltipForm
from megforms.utils import get_permission_by_name, localize_time_range, DateTimeRange, \
    get_ward_label, get_document_lead_label, validate_and_sort_multi_file_upload
from megforms.widgets import CustomModelChoiceField, CustomMultipleChoiceField, FolderChoiceNameIterator, \
    GroupedWardChoiceIterator, InstitutionGrouperIterator, AnnotateUserNameIterator


class WardsFormMixin(forms.Form):
    """
    Updates fields to add a 'wards' field with ringfencing and custom label.
    """
    institution: Institution
    auditor: Auditor
    wards = CustomMultipleChoiceField(queryset=Ward.objects.published(), required=False, iterator=GroupedWardChoiceIterator, label=_('Wards'))

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['wards'].queryset = self.auditor.allowed_wards.for_institution(self.institution)
        self.fields['wards'].label = get_ward_label(self.institution, capitalize=True, plural=True)

    def clean_wards(self):
        selected_wards: QuerySet = self.cleaned_data['wards']
        if hasattr(self, 'instance') and self.instance.pk:
            # re-add any wards the document belongs to, but are excluded from choices
            selected_wards |= self.instance.wards.exclude(pk__in=self.fields['wards'].queryset.values_list('pk'))
        return selected_wards

    class Media:
        js = (
            'js/wards-multiselect.js',
        )


class DocumentBulkUploadForm(forms.Form):
    folder = CustomModelChoiceField(Folder.objects.none(), label=_('Upload to folder'), required=False, iterator=FolderChoiceNameIterator)
    review_interval = forms.TypedChoiceField(choices=((None, "---------"),) + REVIEW_FREQUENCY_CHOICES, label=_('Review interval'), empty_value=None, initial=None, required=False)
    creation_date = forms.DateField(label=_('Last reviewed date'), initial=datetime.date.today, widget=DateInput(attrs={'class': 'date-picker'}, format=settings.DATE_INPUT_FORMATS[0]))
    reviewer = forms.ModelChoiceField(Auditor.objects.published(), label=_('Approver'), required=True)
    contributors = forms.ModelMultipleChoiceField(Auditor.objects.none(), label=_('Reviewers'), required=False)
    document_files = MultiFileFormField(label=_('Files'), widget=MultiFileClearableInput(), help_text=_('Select one or multiple files inside the dialog'), validators=[FileExtensionValidator(allowed_extensions=ALLOWED_DOCUMENT_EXTENSIONS)])
    source_file = forms.FileField(label=_('Word version'), widget=forms.ClearableFileInput(), help_text=_('Editable version of the document'), validators=[FileExtensionValidator(allowed_extensions=ALLOWED_SOURCE_DOCUMENT_EXTENSIONS)], required=False)
    single_document = forms.BooleanField(label=_('Treat multiple files as single document'), required=False, help_text=_('Tick this to create a single document where each file represents a historical version.'))
    initial_version = forms.IntegerField(label=_('Initial version'), min_value=FIRST_REVISION, initial=FIRST_REVISION, help_text=_('Override initial version of the document to start at higher version than 1'))
    version_name = forms.CharField(label=_('Version name'), required=False, help_text=_('Optional version name that could be used instead of the automatically assigned version'), max_length=10)
    audit_forms = forms.ModelMultipleChoiceField(AuditForm.objects.none(), label=_('Forms'), required=False)
    documents = forms.ModelMultipleChoiceField(Document.objects.none(), label=_('Documents'), required=False, help_text=_('You can link to other documents that have relevance to the uploaded documents.'))
    required_approvals = forms.IntegerField(label=_('Required approvals'), min_value=1, initial=1, help_text=_('Define how many users must approve new document versions before publishing, approvals can come from the approver or reviewers. Default 1 means only the approver needs to approve the document'))
    publish = forms.BooleanField(label=_('Approve documents'), required=False, help_text=_('Tick this box to automatically approve and publish the documents after upload'))
    leads = forms.ModelMultipleChoiceField(Auditor.objects.none(), label=_('Leads'), required=False, help_text=Document._meta.get_field('leads').help_text)
    category = forms.ModelChoiceField(DocumentCategory.objects.none(), label=_('Category'), required=False)

    def __init__(self, *args, auditor: Auditor, institution: Institution, **kwargs):
        self.auditor = auditor
        self.institution = institution
        super().__init__(*args, **kwargs)
        review_permission = get_permission_by_name('megdocs.approve_version')
        # Limit choice of reviewers to just users having approve permission
        self.fields['reviewer'].queryset = self.fields['reviewer'].queryset.annotate_display_name()
        self.fields['reviewer'].queryset &= Auditor.objects.active_users() \
            .for_institution(institution).with_permission(review_permission) \
            .annotate_display_name()
        self.fields['leads'].queryset = self.fields['reviewer'].queryset
        self.fields['leads'].label = get_document_lead_label(institution, plural=True, capitalize=True)
        # Disable publish checkbox if user does not have approve permission
        self.fields['publish'].disabled = not auditor.user.has_perm('megdocs.approve_version')
        self.fields['folder'].queryset = auditor.allowed_folders(permissions=["add_document"], institution=institution)
        self.fields['contributors'].queryset = self.fields['reviewer'].queryset
        self.fields['review_interval'].coerce = self.review_interval_coerce
        self.fields['audit_forms'].queryset = auditor.allowed_forms.for_institution(institution)
        self.fields['documents'].queryset = Document.objects.published().for_institution(institution).for_user(auditor.user)

        category_qs: DocumentCategoryQuerySet = DocumentCategory.objects.published().for_institution(institution)
        if category_qs.exists():
            self.fields['category'].queryset = category_qs
        else:
            self.fields['category'].queryset = DocumentCategory.objects.none()
            self.fields['category'].disabled = True
            self.fields['category'].widget = HiddenInput()

    def clean_document_files(self) -> Sequence[UploadedFile]:
        if not self.files.getlist('document_files'):
            raise ValidationError(_("A document should be selected"))
        return validate_and_sort_multi_file_upload(self.fields['document_files'], self.files.getlist('document_files'))

    def review_interval_coerce(self, review_interval):
        for interval in REVIEW_FREQUENCY_CHOICES:
            if review_interval == str(interval[0]):
                return interval[0]

    def get_uploaded_files(self) -> Iterator[Tuple[str, UploadedFile]]:
        """ Iterates over uploaded files """
        file: UploadedFile
        for file in self.cleaned_data['document_files']:
            yield Path(file.name).stem, file

    def get_document_name(self, file_names: Iterable[str]) -> str:
        """
        Given a set of document names, returns a common prefix of the file names
        """
        file_names = list(file_names)
        name = ''
        first_name = file_names[0]
        for i in range(len(first_name)):
            new_name = first_name[:i + 1]
            if not all(n.startswith(new_name) for n in file_names):
                break
            name = new_name
        # Strip out whitespace from the end of file name.
        # If the file name is blank, use the first file name
        name = name.rstrip(' -_') or first_name
        return name[:70]

    @transaction.atomic()
    def create_document(self) -> Document:
        reviewer: Optional[Auditor] = self.cleaned_data['reviewer']
        audit_forms: Optional[Auditor] = self.cleaned_data['audit_forms']
        publish: bool = self.cleaned_data['publish']
        source_file: Optional[UploadedFile] = self.cleaned_data.get('source_file')
        version: Optional[Version] = None

        document: Document = Document.objects.create(
            name=self.get_document_name(name for name, file in self.get_uploaded_files()),
            owner=self.auditor,
            institution=self.institution,
            review_interval=self.cleaned_data['review_interval'],
            folder=self.cleaned_data.get('folder'),
            category=self.cleaned_data.get('category'),
        )
        if audit_forms:
            document.forms.set(audit_forms)
        if leads := self.cleaned_data.get('leads'):
            document.leads.set(leads)
        document.documents.set(self.cleaned_data['documents'])

        for revision, (name, file) in enumerate(self.get_uploaded_files(), start=self.cleaned_data['initial_version']):
            version: Version = Version.objects.create(
                revision=revision,
                version_name=self.cleaned_data['version_name'],
                document=document,
                creation_date=self.cleaned_data['creation_date'],
                creator=self.auditor,
                reviewer=reviewer,
                file=file,
                source=source_file,
                approved=publish,
            )
            version.contributors.set(self.cleaned_data.get('contributors'))
        if publish and version:
            self.approve(version)

        return document

    def approve(self, version: Version):
        """
        Marks version as approved and publishes the document.
        This method intentionally skips verifications steps normally used in approving.
        """
        VersionApprovalConfig(version).force_approve()

    def clean(self):
        data: dict = super().clean()
        if data['publish'] and data['required_approvals'] > 1:
            approvers = {data['reviewer'], *data['contributors']}
            if data['required_approvals'] > len(approvers):
                raise ValidationError({
                    'required_approvals': gettext(
                        "Cannot automatically publish document that requires more approvals than are users that can approve."),
                })
        if len(data.get('document_files', [])) > 1:
            if data.get('source_file'):
                raise ValidationError({
                    'source_file': gettext("Cannot upload a word document with more than one file in Files."),
                })
            elif data['version_name']:
                raise ValidationError({
                    'version_name': gettext(
                        "Cannot upload multiple documents with the same version name"),
                })
        return data

    @transaction.atomic()
    def create_documents(self) -> Sequence[Document]:
        reviewer: Optional[Auditor] = self.cleaned_data['reviewer']
        audit_forms: Optional[Auditor] = self.cleaned_data['audit_forms']
        publish: bool = self.cleaned_data['publish']
        source_file: Optional[UploadedFile] = self.cleaned_data.get('source_file')

        documents: List[Document] = []

        for name, file in self.get_uploaded_files():
            document: Document = Document.objects.create(
                name=self.get_document_name([name]),
                owner=self.auditor,
                institution=self.institution,
                review_interval=self.cleaned_data['review_interval'],
                folder=self.cleaned_data.get('folder'),
                required_approvals=self.cleaned_data['required_approvals'],
                category=self.cleaned_data.get('category'),
            )
            if audit_forms:
                document.forms.set(audit_forms)
            if leads := self.cleaned_data.get('leads'):
                document.leads.set(leads)
            document.documents.set(self.cleaned_data['documents'])
            documents.append(document)
            version: Version = Version.objects.create(
                document=document,
                creation_date=self.cleaned_data['creation_date'],
                creator=self.auditor,
                reviewer=reviewer,
                file=file,
                source=source_file,
                version_name=self.cleaned_data['version_name'],
                revision=self.cleaned_data['initial_version'],
            )
            version.contributors.set(self.cleaned_data.get('contributors'))
            transaction.on_commit(lambda: parse_document_content.delay(version.pk))
            if publish:
                self.approve(version)
        return documents

    def create(self) -> Sequence[Document]:
        if self.cleaned_data['single_document']:
            return self.create_document(),
        else:
            return self.create_documents()

    @property
    def additional_settings(self) -> Sequence[str]:
        return "reviewer", "contributors", "required_approvals", "publish", "review_interval", "creation_date",

    @property
    def advanced_settings(self) -> Sequence[str]:
        return "initial_version", "audit_forms", "documents", "version_name", "leads",

    class Media:
        js = (
            'js/bootstrap-multiselect.js',
            'js/document-upload.js',
        )
        css = {
            'all': (
                'css/bootstrap-multiselect.css',
                'css/datepicker3.css',
            ),
        }


class DocumentEditForm(forms.ModelForm):
    PARAGRAPH = 'paragraph'
    INLINE = 'inline'
    folder = CustomModelChoiceField(Folder.objects.none(), label=_('Folder'), required=False, iterator=FolderChoiceNameIterator)
    reviewer = forms.ModelChoiceField(Auditor.objects.none(), required=False, label=_('Approver'), help_text=_("The approver of the document's current version."))
    contributors = forms.ModelMultipleChoiceField(label=_('Reviewers'), queryset=Auditor.objects.published(), required=False)

    def __init__(self, *args, user: User, institution: Institution, versions: VersionQuerySet, **kwargs):
        self.auditor = user.auditor
        self.institution = institution
        super().__init__(*args, **kwargs)
        auditors: AuditorQueryset = Auditor.objects.filter(institution=institution, user__is_active=True).published().annotate_display_name()
        if not user.has_perm('megdocs.change_document_owner'):
            self.fields.pop('owner')
        if 'owner' in self.fields:
            self.fields['owner'].queryset = self.fields['owner'].queryset.annotate_display_name()
            self.fields['owner'].queryset &= auditors.with_permission('megdocs.change_document')
        self.fields['current_version'].queryset = versions.filter(approved=True)
        self.fields['reviewer'].queryset = get_document_reviewer_choices(self.instance, auditors)
        self.fields['contributors'].queryset = auditors.with_permission('megdocs.change_version')
        self.fields['leads'].queryset = self.fields['reviewer'].queryset
        self.fields['leads'].label = get_document_lead_label(institution, plural=True, capitalize=True)

        current_version: Version = self.get_current_version()
        if current_version:
            self.fields['reviewer'].initial = current_version.reviewer
            self.fields['contributors'].initial = current_version.contributors.all()
        self.fields['folder'].queryset = self.auditor.allowed_folders(permissions=["add_document", "change_document"], institution=institution)
        self.fields['forms'].queryset = self.auditor.allowed_forms.for_institution(institution)
        self.fields['documents'].queryset = Document.objects.published().for_institution(institution).for_user(user).exclude(pk=self.instance.pk)

        category_qs: DocumentCategoryQuerySet = DocumentCategory.objects.published().for_institution(institution)
        if category_qs.exists():
            self.fields['category'].queryset = category_qs
        else:
            self.fields['category'].queryset = DocumentCategory.objects.none()
            self.fields['category'].disabled = True
            self.fields['category'].widget = HiddenInput()

    def get_current_version(self) -> Version:
        current_version: Version = self.instance.current_version
        # there is no current version when document is still in review for the first time
        if not current_version:
            return self.instance.versions.first()
        return current_version

    def clean(self):
        cleaned_data = super().clean()
        if self.instance.current_version and cleaned_data.get('reviewer') and not cleaned_data.get('current_version'):
            raise ValidationError({'reviewer': _("You can't assign a reviewer with no version to be reviewed.")})
        return cleaned_data

    def clean_forms(self):
        hidden_forms = self.instance.forms.all().exclude(pk__in=self.auditor.allowed_forms)
        return self.cleaned_data.get('forms') | hidden_forms

    def clean_documents(self):
        hidden_documents = self.instance.documents.all().exclude(pk__in=self.fields['documents'].queryset)
        return self.cleaned_data.get('documents') | hidden_documents

    def save_reviewer(self):
        current_version: Version = self.get_current_version()
        if self.cleaned_data['reviewer'] and current_version:
            if self.cleaned_data['reviewer'] != current_version.reviewer:
                return Version.objects.filter(pk=current_version.pk).update(reviewer=self.cleaned_data['reviewer'])

    @transaction.atomic()
    def save(self, commit=True):
        current_version: Version = self.get_current_version()
        if current_version:
            current_version.contributors.set(self.cleaned_data.get('contributors'))
        return super(DocumentEditForm, self).save(commit)

    @property
    def field_groups(self) -> tuple[tuple]:
        return (
            (self.PARAGRAPH, ('name', 'description', 'folder', 'category', 'tags', )),
            (self.PARAGRAPH, 'links'),
            (self.INLINE, ('owner', 'reviewer', 'review_interval', )),
            (self.PARAGRAPH, ('required_approvals', )),
            (self.INLINE, ('contributors', 'leads', )),
            (self.PARAGRAPH, ('current_version', 'archived', )),
            (self.INLINE, ('forms', 'documents', )),
        )

    class Meta:
        model = Document
        fields = 'name', 'description', 'tags', 'owner', 'current_version', 'reviewer', 'contributors', 'required_approvals', 'leads', 'review_interval', 'folder', 'category', 'archived', 'forms', 'documents',
        widgets = {'description': forms.Textarea(attrs={'rows': 2})}

    class Media:
        js = (
            'js/bootstrap-multiselect.js',
            'js/document-edit.js',
        )
        css = {
            'all': ('css/bootstrap-multiselect.css',),
        }


class NoResultsMessageMixin:
    @property
    def no_results_message(self) -> str:
        """ Message to be displayed when no results are found, based on the search string"""
        queries = []
        if self.is_valid():
            if self.cleaned_data['q']:
                queries.append(_('matching "{q}"').format(**self.cleaned_data))
            if self.cleaned_data['owners']:
                owners = ', '.join(str(auditor) for auditor in self.cleaned_data['owners'])
                queries.append(_('owned by {owners}').format(owners=owners))
        return _('Could not find any documents {}').format(', '.join(queries))


class SearchMixin(TooltipForm, NoResultsMessageMixin, forms.Form):
    owners = forms.ModelMultipleChoiceField(label=_('Owner'), queryset=Auditor.objects.published(), required=False)

    def __init__(self, *args, institution: Institution, **kwargs):
        super().__init__(*args, **kwargs)
        # Limit owner choices to just users who actually own documents
        document_owner_ids: Iterable[int] = Document.objects.for_institution(institution).values_list('owner_id', flat=True)
        self.fields['owners'].queryset &= Auditor.objects.for_institution(institution).filter(pk__in=document_owner_ids)

    class Media:
        js = (
            'js/bootstrap-multiselect.js',
            'js/document-search.js',
            'js/activate-tooltips.js',
        )
        css = {
            'all': ('css/bootstrap-multiselect.css',),
        }


class DocumentVersionForm(forms.ModelForm):
    def __init__(self, *args, institution, owner: Auditor, **kwargs):
        super().__init__(*args, **kwargs)
        auditors: AuditorQueryset = Auditor.objects.filter(institution=institution, user__is_active=True).published().annotate_display_name()
        self.fields['reviewer'].label = _('Approver')
        self.fields['contributors'].label = _('Reviewers')
        self.fields['reviewer'].queryset = get_document_reviewer_choices(document=self.instance.document, auditors=auditors)
        self.fields['contributors'].queryset = self.fields['contributors'].queryset.annotate_display_name()
        self.fields['contributors'].queryset &= auditors.with_permission('megdocs.change_version')
        if self.instance.document.current_version_id:
            self.initial['contributors'] = self.instance.document.current_version.contributors.all()
        if not self.instance.document.checkboxes.published().exists():
            self.fields['resets_checkbox'].widget = HiddenInput()

    class Media:
        css = {
            'all': (
                'css/bootstrap-multiselect.css',
            ),
        }
        js = (
            'js/bootstrap-multiselect.js',
            'js/version-form.js',
        )

    class Meta:
        fields = 'file', 'version_name', 'source', 'reviewer', 'contributors', 'summary', 'resets_checkbox',
        model = Version


class CreateFolderForm(WardsFormMixin, forms.ModelForm):
    def __init__(self, *args, user: User, institution: Institution, **kwargs):
        self.auditor = user.auditor
        self.institution = institution
        super().__init__(*args, **kwargs)
        queryset = self.auditor.allowed_folders(permissions=["add_folder"], institution=institution)
        if self.instance:
            queryset = queryset.exclude(pk=self.instance.pk)
        self.fields['parent'].queryset = queryset

    class Meta:
        model = Folder
        fields = 'name', 'description', 'parent', 'wards',
        widgets = {'description': forms.Textarea(attrs={'rows': 2})}

    class Media:
        css = {
            'all': (
                'css/bootstrap-multiselect.css',
            ),
        }
        js = (
            'js/bootstrap-multiselect.js',
            'js/folder-create.js',
        )


class FolderPermissionRuleForm(forms.ModelForm):
    role = ChoiceField(choices=FOLDER_PERMISSION_RULE_ROLE_CHOICES, label=_('Role'))
    folders = CustomMultipleChoiceField(Folder.objects.none(), label=_('Folders'), required=False, iterator=FolderChoiceNameIterator)
    users = CustomMultipleChoiceField(User.objects.all(), required=False, iterator=AnnotateUserNameIterator)

    def __init__(self, *args, institution: Institution, user: User, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['users'].queryset = User.objects.filter(pk__in=Auditor.objects.for_institution(institution).values_list('user_id'))
        self.fields['teams'].queryset = Team.objects.published().filter(institution=institution)
        self.fields['folders'].queryset = user.auditor.allowed_folders(permissions=["add_folderpermissionrule"], institution=institution)
        self.fields['teams'].required = False
        if self.instance.pk:
            self.fields['role'].initial = self.instance.role_index

    def clean_users(self):
        if not self.cleaned_data.get('users') and not self.cleaned_data.get('teams'):
            raise ValidationError(_("Both 'users' and 'teams' cannot be empty."))
        return self.cleaned_data['users']

    @transaction.atomic()
    def save(self, commit=True):
        rule: FolderPermissionRule = super().save(commit)
        if rule.permissions:
            rule.permissions.clear()
        role_permissions = Permission.objects.filter(
            codename__in=FOLDER_PERMISSION_CODENAMES_MAP[int(self.cleaned_data['role'])],
            content_type__app_label__in=FOLDER_PERMISSION_APPNAMES
        ).all()
        rule.permissions.add(*role_permissions)
        return rule

    class Meta:
        model = FolderPermissionRule
        fields = 'name', 'folders', 'role', 'teams', 'users'

    class Media:
        js = (
            'js/bootstrap-multiselect.js',
            'js/folder-permission-rule-crud.js',
        )
        css = {
            'all': (
                'css/bootstrap-multiselect.css',
            ),
        }


class FolderPermissionRuleSearchForm(SearchMixin):
    q = forms.CharField(label=_('Search all rules'), required=False, help_text=_("You can search for titles or rules containing the search term."))

    def search(self, qs: FolderPermissionRuleQueryset) -> FolderPermissionRuleQueryset:
        query: str = self.cleaned_data['q']
        owners: Sequence[Auditor] = self.cleaned_data['owners']
        if query:
            qs = qs.search(query)
        if owners:
            qs = qs.filter(owner__in=owners)
        return qs


class DocumentLinkForm(forms.ModelForm):

    class Meta:
        model = DocumentLink
        fields = 'name', 'url',


class DocumentFilterForm(NoResultsMessageMixin, forms.Form):
    """
    Provides document filtering logic
    """
    qip = True

    date_range = DateRangeField(widget=DateRangeWidget(
        picker_options={
            'showDropdowns': True,
            'autoUpdateInput': True,
            'minYear': 2010,
            'maxYear': timezone.now().year + 1,
            'linkedCalendars': False,
        },
        format='%Y-%m-%d',
    ), help_text=_('Filter by modified date'), label=_('Date range'))
    date_type = forms.MultipleChoiceField(label=_('Date type'), choices=DOCUMENT_FILTER_DATE_CHOICES, required=False)
    owners = forms.ModelMultipleChoiceField(label=_('Owner'), queryset=Auditor.objects.published(), required=False)
    reviewers = forms.ModelMultipleChoiceField(label=_('Reviewer'), queryset=Auditor.objects.published(), required=False)
    folders = CustomMultipleChoiceField(queryset=Folder.objects.published(), label=_('Folders'), required=False, iterator=InstitutionGrouperIterator)
    institutions = forms.ModelMultipleChoiceField(label=_('Institutions'), queryset=Institution.objects.published(), required=False)
    categories = forms.ModelMultipleChoiceField(label=_('Categories'), queryset=DocumentCategory.objects.published(), required=False)
    q = forms.CharField(label=_("Search..."), required=False, help_text=_("You can search for titles or documents containing the search term. Please note: Partial search will only work for titles"))
    q_search_in = forms.MultipleChoiceField(
        label='',
        widget=forms.CheckboxSelectMultiple(),
        choices=DOCUMENT_SEARCH_TEXT_TYPES,
        initial=[v for v, l in DOCUMENT_SEARCH_TEXT_TYPES],
        required=False,
    )

    def __init__(self, *, institution: Institution, user: User = None, initial=None, **kwargs):
        now = timezone.localtime()
        self.user = user
        self.institution = institution
        defaults = {
            'date_range': (datetime.date(2010, 1, 1), now.date()),
            'date_type': [DOCUMENT_FILTER_DATE_MODIFIED],
            'folders': Folder.objects.none(),
            'owners': Auditor.objects.none(),
            'reviewers': Auditor.objects.none(),
            'institutions': Institution.objects.filter(pk=institution.pk) if institution else [],
            'categories': [],
        }
        if initial:
            defaults.update(initial)
        initial = defaults
        super().__init__(initial=initial, **kwargs)
        self.fields['folders'].queryset = self.user.auditor.allowed_folders().for_institutions(self.selected_institutions)
        document_owner_ids: Iterable[int] = Document.objects.for_institutions(self.selected_institutions).values_list('owner_id', flat=True)
        self.fields['owners'].queryset = self.fields['owners'].queryset.annotate_display_name()
        self.fields['owners'].queryset &= Auditor.objects.for_institutions(self.selected_institutions).filter(pk__in=document_owner_ids)
        document_reviewer_ids: Iterable[int] = Document.objects.for_institutions(self.selected_institutions).values_list('current_version__reviewer_id', flat=True)
        self.fields['reviewers'].queryset = self.fields['reviewers'].queryset.annotate_display_name()
        self.fields['reviewers'].queryset &= Auditor.objects.for_institutions(self.selected_institutions).filter(pk__in=document_reviewer_ids)
        self.fields['institutions'].queryset = self.all_institutions

        document_category_qs = DocumentCategory.objects.published().for_institution(self.institution)
        if document_category_qs.exists():
            self.fields['categories'].queryset = document_category_qs
        else:
            self.fields['categories'].disabled = True
            self.fields['categories'].widget = HiddenInput()

        today = now.date()
        widget = self.fields['date_range'].widget
        widget.picker_options = dict(
            ranges={str(label): value for label, value in date_range_choices(today).items()},
            locale={
                'format': 'YYYY-MM-DD',
                'applyLabel': gettext('Apply'),
                'cancelLabel': gettext('Cancel'),
                'customRangeLabel': gettext('Custom Date Range'),
            },
            **widget.picker_options
        )

    @cached_property
    def all_institutions(self) -> InstitutionQuerySet:
        institutions = self.institution.group_institutions
        if not isinstance(institutions, QuerySet):
            institutions = Institution.objects.published().filter(pk__in=(i.pk for i in institutions))
        return institutions & self.user.auditor.institutions

    @cached_property
    def selected_institutions(self) -> InstitutionQuerySet:
        return self.data_or_initial.get('institutions') or Institution.objects.filter(pk=self.institution.pk)

    def filter(self, qs: Union[DocumentQuerySet, VersionQuerySet]) -> DocumentQuerySet:
        is_documents: bool = isinstance(qs, DocumentQuerySet)
        is_change_requests: bool = isinstance(qs, DocumentChangeRequestQuerySet)
        owners: Sequence[Auditor] = self.data_or_initial['owners']
        reviewers: Sequence[Auditor] = self.data_or_initial['reviewers']
        search: str = self.data_or_initial.get('q')
        search_in: list[str] = self.data_or_initial.get('q_search_in', [])

        filter_kwarg = '' if is_documents else 'document__'
        if search:
            qs = qs.search(search, search_in)
        if owners:
            qs = qs.filter(**{filter_kwarg + 'owner__in': owners})
        if reviewers:
            if is_documents:
                qs = qs.filter(current_version__reviewer__in=reviewers)
            elif is_change_requests:
                qs = qs.filter(document__current_version__reviewer__in=reviewers)
            else:
                qs = qs.filter(reviewer__in=reviewers)

        folder: Folder
        for folder in self.data_or_initial['folders']:
            qs = qs.filter(**{filter_kwarg + 'folder__in': folder.get_descendants(include_self=True)})
        if institutions := self.data_or_initial['institutions']:
            qs = qs.for_institutions(institutions)
        elif self.institution:
            qs = qs.for_institution(self.institution)
        if categories := self.data_or_initial['categories']:
            qs = qs.for_categories(categories)
        return self.filter_by_date(qs, is_documents)

    def filter_by_date(self, qs: Union[DocumentQuerySet, VersionQuerySet], is_documents: bool) -> DocumentQuerySet:
        date_q: Q = Q()
        time_range = self.time_range
        date_filter_types = self.data_or_initial['date_type']
        if DOCUMENT_FILTER_DATE_MODIFIED in date_filter_types:
            date_q: Q = Q(modified__range=time_range)
            if is_documents:
                date_q |= Q(current_version__modified__range=time_range)
        if DOCUMENT_FILTER_DATE_NEXT_REVIEW in date_filter_types:
            if is_documents:
                date_q |= Q(pk__in=qs.review_range(*time_range))
            else:
                documents = Document.objects.published().for_institution(self.institution)
                date_q |= Q(document_published__in=documents.review_range(*time_range))
        return qs.filter(date_q)

    @cached_property
    def time_range(self) -> Optional[DateTimeRange]:
        start, end = self.data_or_initial['date_range']
        return localize_time_range(start, end)

    @cached_property
    def data_or_initial(self) -> dict:
        data = self.initial
        if self.is_valid():
            data.update(self.cleaned_data)
        return data


class DocumentShareForm(forms.Form):
    users = forms.ModelMultipleChoiceField(queryset=Auditor.objects.none(), label=_('Users'), help_text=_('Select users to share the document with'), required=False)
    teams = forms.ModelMultipleChoiceField(queryset=Team.objects.none(), label=_('Teams'), help_text=_('Select teams to share the document with'), required=False)

    def __init__(self, *args, instance: Document, user: User, **kwargs):
        super().__init__(*args, **kwargs)
        self.document = instance
        self.user = user
        self.fields['users'].queryset = Auditor.objects.prefetch_related(
            'user__user_permissions__content_type',
            'user__groups__permissions__content_type',
        ).published().active_users().with_email_address().can_view_document(self.document)
        if permission_rules := self.document.folder_permission_rules:
            self.fields['teams'].queryset = Team.objects.published().filter(
                Q(pk__in=permission_rules.filter(permissions__codename__in=['view_document']).values_list('teams__pk', flat=True)) |
                Q(pk__in=self.fields['users'].queryset.values_list('teams__pk', flat=True))
            )
        else:
            self.fields['teams'].queryset = Team.objects.published().for_institution(self.document.institution)

    def clean(self):
        data: dict = super().clean()
        if not data.get('users') and not data.get('teams'):
            raise ValidationError({
                'users': gettext("Either users or teams should be chosen for sharing a document"),
            })
        return data

    @transaction.atomic()
    def share_document(self) -> set[Auditor]:
        """
        E-mails a link to the document asynchronously to the selected users
        and users in selected teams who can view the document.

        :returns: A set of auditors who will receive the e-mail.
        """
        auditors: set[Auditor] = set(self.cleaned_data['users'])
        teams = self.cleaned_data['teams']
        if teams.exists():
            auditors |= set(teams.auditors().active_users()) & set(self.fields['users'].queryset)
        for auditor in auditors:
            share_document.delay(auditor.pk, str(self.user.auditor), self.document.id)
        return auditors


class DocumentVersionDeclineForm(forms.Form):
    reason = forms.CharField(
        min_length=3, label=_('Reason'), help_text=_('Reason for declining this version?'), required=True, widget=forms.Textarea
    )


class DocumentVersionReUploadForm(forms.ModelForm):
    """ From used to re-upload a file after it was declined by approver """
    class Meta:
        model = Version
        fields = 'file',


class DocumentEditRequestForm(forms.ModelForm):
    is_archived = forms.BooleanField(label=_('My suggestion is to archive this document'), initial=False, required=False)

    class Meta:
        model = DocumentChangeRequest
        fields = ['description', 'reason']

    def save(self, commit=True):
        if self.cleaned_data['is_archived']:
            self.instance.type = CHANGE_REQUEST_ACTION_TYPE_ARCHIVE

        return super().save(commit=commit)


class DocumentNewRequestForm(forms.ModelForm):
    class Meta:
        model = DocumentChangeRequest
        fields = ['description', 'reason', 'owner']
        labels = {
            'description': _('Description of document'),
            'reason': _('Reason for new document suggestion'),
        }
        help_texts = {
            'description': _('Please include details like document type, category, or other important information'),
            'reason': '',
            'owner': _('You will need to choose an owner of this document. The owner will be the person who can approve your request'),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['owner'].queryset = self.fields['owner'].queryset.annotate_display_name()
        self.fields['owner'].queryset &= Auditor.objects.for_institution(self.instance.institution).filter(
            user__is_active=True
        ).published().annotate_display_name().with_permission('megdocs.change_document')


class ChangeRequestNewVersionForm(forms.ModelForm):
    class Meta:
        model = Version
        fields = ['file', 'source']

    def __init__(self, change_request: DocumentChangeRequest, auditor: Auditor, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.change_request = change_request
        self.auditor = auditor

    def save(self, commit=True):
        return self.change_request.new_version(self.auditor, self.instance)
